import logo from './logo.svg';
import './App.css';
import { Rotes, Route } from 'react-router-dom';

const App = () => (

<>
<Routes>




  
</Routes>
</>

)

     
export default App;
