class User < ApplicationRecord
has_many :appointment

validates :name, uniqueness: true

end
